# Byte Vortex Launcher
Launcher Android nativo com identidade Byte Vortex, grade de aplicativos instalados, busca, relógio e acesso às configurações. Android 6.0+ (API 23).

Instale o APK e, quando o Android perguntar, escolha **Byte Vortex Launcher** como app de tela inicial. Também dá para selecionar em Configurações > Apps > Apps padrão > App de início.
